"use strict";
(self["webpackChunk_jupyterlab_examples_toolbar_button"] = self["webpackChunk_jupyterlab_examples_toolbar_button"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * The plugin registration information.
 */
const plugin = {
    id: '@jupyterlab-examples/toolbar-button:plugin',
    description: 'A JupyterLab extension adding a button to the Notebook toolbar.',
    autoStart: true,
    activate: () => {
        // Nothing is needed
    }
};
/**
 * Export the plugin as default.
 */
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.620e3019e591817b9d02.js.map